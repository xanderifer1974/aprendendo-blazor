﻿namespace Catalogo_Blazor.Shared.Recursos;

public class Paginacao
{
    public int Pagina { get; set; } = 1;
    public int QuantidadePorPagina { get; set; } = 5;
}
