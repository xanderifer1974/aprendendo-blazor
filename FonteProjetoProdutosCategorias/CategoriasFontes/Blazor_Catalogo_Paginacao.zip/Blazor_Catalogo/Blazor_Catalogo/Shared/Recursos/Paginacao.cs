﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blazor_Catalogo.Shared.Recursos
{
    public class Paginacao
    {
        public int Pagina { get; set; } = 1;
        public int QuantidadePorPagina { get; set; } = 5;
    }
}
